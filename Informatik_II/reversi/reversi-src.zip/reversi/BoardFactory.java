/*   */ package reversi;
/*   */ 
/*   */ 
/*   */ 
/*   */ public class BoardFactory
/*   */ {
/*   */   public static GameBoard create()
/*   */   {
/* 9 */     return new TextGameBoard();
/*   */   }
/*   */ }


/* Location:              /usr/share/java/reversi.jar!/reversi/BoardFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */