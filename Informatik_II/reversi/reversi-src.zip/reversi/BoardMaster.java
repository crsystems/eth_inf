package reversi;

import java.awt.Image;

abstract interface BoardMaster
{
  public abstract Image getImage();
}


/* Location:              /usr/share/java/reversi.jar!/reversi/BoardMaster.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */